// https://quescol.com/interview-preparation/fibonacci-series-in-c-program
// Fibonacci Iterative by looping
#include <stdio.h>
#include <conio.h> 
int main() {
    int n = 10;
    printf("n = 10\n");
    int first = 0, second = 1, result, i;
    printf("Fibonacci Series is:\n");
    for (i = 0; i < n; i++) {
        if (i <= 1) result = i;
        else {
            result = first + second;
            first = second;
            second = result;
        }
        printf("%d ", result);
    }
    printf("\n");
    return 0;
}