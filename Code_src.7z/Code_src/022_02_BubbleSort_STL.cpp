#include<iostream>
#include <vector>
using namespace std;
void swapping(int& a, int& b) {      //swap the content of a and b
    int temp;
    temp = a;
    a = b;
    b = temp;
}

void display(vector <int>array, int size) {
    for (int i = 0; i < size; i++)
        cout << array[i] << " ";
    cout << endl;
}

void bubbleSort(vector <int> & array, int size) {
    for (int i = 0; i < size; i++) {
        int swaps = 0;         //flag to detect any swap is there or not
        for (int j = 0; j < size - i - 1; j++) {
            if (array[j] > array[j + 1]) {
                //when the current item is bigger than next
                swapping(array[j], array[j + 1]);
                swaps = 1;    //set swap flag
            }
        }
        if (!swaps)
            break;       // No swap in this pass, so array is sorted
    }
}

int main() {
    vector <int> arr = { 56, 98, 78, 12, 30, 51 };
    int n = (int)arr.size();
    cout << "Array before Sorting: ";
    display(arr, n);
    bubbleSort(arr, n);
    cout << "Array after Sorting: ";
    display(arr, n);
}