#include <iostream>
#include <vector>
using namespace std;

int searchResult(vector<int> arr, int k) {
    vector<int>::iterator it;
    it = find(arr.begin(), arr.end(), k);
    if (it != arr.end()) {
        cout << "arr.end() - arr.begin(): " << arr.end() - arr.begin() << endl; // 6
        cout << "it - arr.begin(): " << it - arr.begin() << endl;  // 3
        return (int)(it - arr.begin());
    } else
        return -1;
}

int main() {
    vector<int> arr = { 1, 2, 3, 4, 5, 6 };
    int k = 4;
    cout << searchResult(arr, k) << endl;
    return 0;
}