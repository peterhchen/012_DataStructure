// CPP program to implement
// Binary Search in
// Standard Template Library (STL)
#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

void show(int a[], int arraysize) {
    for (int i = 0; i < arraysize; ++i)
        cout << a[i] << ",";
}

int main() {
    int a[] = { 1, 5, 8, 9, 6, 7, 3, 4, 2, 0 };
    int asize = sizeof(a) / sizeof(a[0]);
    cout << "The array is:" << endl;
    show(a, asize);  // 1,5,8,9,6,7,3,4,2,0,
    cout << endl << endl;

    sort(a, a + asize);
    cout << "The array after sorting is:" << endl;
    show(a, asize);  // 0,1,2,3,4,5,6,7,8,9,
    cout << endl << endl;
    
    int k = 2;
    cout << "1) Search for index of element k = " << k << endl;
    if (binary_search(a, a + 10, 2))
        cout << "Element found in the array" << endl;
    else
        cout << "Element not found in the array" << endl;
    cout << endl;
    
    k = 10;
    cout << "2) Search for index of element k = " << k << endl;
    if (binary_search(a, a + 10, 11))
        cout << "Element found in the array" << endl;
    else
        cout << "Element not found in the array" << endl;
    cout << endl;

    k = 3;
    cout << "3) Search for index of element k = " << k << endl;
    vector<int> arr1 (begin(a), end(a));

    int index = (int)(lower_bound(arr1.begin(), arr1.end(), k) - arr1.begin());
    if (index >=0)
        cout << "Element " << k << " is in array index " << index << endl;
    else
        cout << "Element not found in the array" << endl;
    return 0;
}