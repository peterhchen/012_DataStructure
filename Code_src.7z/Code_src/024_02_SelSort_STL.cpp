#include <iostream>
#include <list>
using namespace std;

void selectionSort(list<short>& l) {
    list<short>::iterator it1;
    list<short>::iterator it2;
    list<short>::iterator it3;
    short min, temp;
    for (it1 = l.begin(); it1 != l.end(); it1++) {
        temp = min = *it1;
        it3 = l.end();
        for (it2 = it1; it2 != l.end(); it2++) {
            if (*it2 < min) {
                min = *it2;
                it3 = it2;
            }
        }
        if (it3 != l.end()) {
            *it1 = min;
            *it3 = temp;
        }
    }
}

int main() {
    list<short> mylist = { 10,1,8,13,14,7,6,5,18,9,19,12,17,15,4,2 };
    list<short>::iterator it;
    cout << "Before Selection Sort:" << endl;
    for (it = mylist.begin(); it != mylist.end(); it++) {
        cout << *it << " ";
    }
    cout << endl;
    selectionSort(mylist);
    cout << "After Selection Sort:" << endl;
    for (it = mylist.begin(); it != mylist.end(); it++) {
        cout << *it << " ";
    }
    cout << endl;
    return 0;
}